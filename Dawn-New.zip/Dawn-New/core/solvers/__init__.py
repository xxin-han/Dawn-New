from .anti_captcha import AntiCaptchaSolver
from .two_captcha import TwoCaptchaSolver
